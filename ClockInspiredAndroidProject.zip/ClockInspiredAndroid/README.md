# Clock-inspired Android app

This is an Android Studio project for a Google Clock-inspired clock UI. It contains a dark Material-style interface with Alarm, Clock, Timer, and Stopwatch tabs.

## Build an APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

You can also use **Build → Generate Signed Bundle / APK** to create a signed release APK.

## Important limitation
The app's alarms are in-app prototype alarms: Android system alarms that reliably ring when the app is closed or the device is locked are not implemented in this starter project. It is not a replacement for the system Google Clock app. The project must be built on a machine with Android Studio/Android SDK; this environment does not have the Android build toolchain, so this download is the source project, not a compiled APK.
